check_config_static
=========

Validate ansible tower variables that are statically verifiable (i.e. configuration permutations)

Requirements
------------

None

Role Variables
--------------

TODO

Dependencies
------------

None

Example Playbook
----------------

See test/main.yml

License
-------

TODO

Author Information
------------------

Chris Meyers

cmeyers@ansible.com
